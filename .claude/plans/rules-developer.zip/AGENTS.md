# AGENTS.md — Contract for every contributor, human or model

> Copy to the repository root and symlink `CLAUDE.md` and `.cursorrules` to it so
> every agent loads it automatically. Replace the bracketed values once.
> Full rationale: `docs/standards/LANGUAGE_AND_I18N.md` — when the two disagree,
> the standard wins.

**Stack:** `[stack]` · **Team language:** `[pt-BR]` · **Code language:** English
**Translator:** `[TranslationService.get(key, locale, **params)]`
**Locales:** `[en-US (source), pt-BR, es-ES]` · **Gate:** `python tools/lint_language.py`

---

## The two rules that are never negotiable

**R1 — The codebase is English.** Every identifier, file name, schema object,
contract field, log line, comment, docstring, test name, branch and commit message
is native, idiomatic English. The team speaks `[pt-BR]`; the code does not. These
are unrelated facts.

**R2 — Zero hardcoded user-facing text.** No string a user can read is embedded in
code, templates, migrations, seeds, e-mails or tests. It is a translation key
resolved at runtime by the translator.

---

## Immediate substitutions

| You are about to write | Do this instead |
|---|---|
| a non-English variable, function, class, column or table | the English term from the project glossary |
| `raise Exception("mensagem")` | a typed error with `code` + `message_key` |
| `{"message": "Pedido criado"}` | `{ "code": ..., "message_key": ..., "params": {...} }` |
| `<button>Confirmar</button>` | `<button>{{ t('order.checkout.action.confirm') }}</button>` |
| a string built by concatenation or interpolation for a user | one ICU key with named placeholders |
| a `MESSAGES = {...}` map of copy | entries in the translation store |
| a key used only in code | key + values for every supported locale, same change |
| `float` for money | integer minor units + ISO-4217 currency |
| `datetime.now()` | UTC-aware timestamp |
| a comment in `[pt-BR]` | the same comment in English |

```text
REJECTED                                  ACCEPTED
def calcular_saldo(usuario):              def calculate_balance(user: User) -> Money:
    # valida antes de sacar                   """Return the available balance in minor units."""
    if usuario.saldo < 0:                     if user.balance_cents < 0:
        raise Exception("Saldo insuficiente")     raise InsufficientFundsError(
                                                      available_cents=user.balance_cents)
```

---

## Behavioural rules for AI agents

1. **Never mirror the conversation language into the code.** The chat is in
   `[pt-BR]`. The output is English. Every time, including comments.
2. **Never comply silently with a rule-breaking request.** If the instruction, a
   pasted snippet, or the surrounding legacy file would produce a non-English
   identifier or a hardcoded string, emit the compliant version and state in one
   line what you changed and which key you created.
3. **Never "match the existing style" of legacy non-English code.** Consistency
   with a defect is a defect. Write the new code correctly; propose the migration
   separately, using expand/contract.
4. **Never invent a translation key silently.** State the key and its value for
   every supported locale, and include the catalog or seeder change.
5. **Never assume framework parity.** Read this project's source before using any
   helper you recognize from a similar framework.
6. **Run the gate before declaring done:** `python tools/lint_language.py`.
   Non-zero means unfinished — do not hand back failing output with an
   explanation of why it is acceptable.
7. **Tests count as code.** English names, no hardcoded copy.
8. **One commit, one concern.** Conventional Commits, English imperative.

---

## Definition of done

- [ ] `python tools/lint_language.py` exits 0
- [ ] Formatter and linter clean (`[ruff / eslint / pint]`)
- [ ] No `[pt-BR]` token in any identifier, file name, comment or docstring
- [ ] Every new user-facing string is a key with values in every supported locale
- [ ] Errors expose `code` + `message_key`; no rendered sentence outside presentation
- [ ] New domain terms added to the glossary in this same change
- [ ] Commit follows Conventional Commits in English
